package com.baoneng.wss.converter;

import com.baoneng.wss.BaseRequest;
import com.baoneng.wss.BaseResponse;
import com.baoneng.wss.WssNetHelper;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.nio.charset.Charset;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okio.Buffer;
import retrofit2.Converter;
import retrofit2.Retrofit;

/**
 * Created by fengyinpeng on 2018/7/12.
 */
public class WssConverter extends Converter.Factory {
    private Gson gson;

    public WssConverter(Gson gson) {
        this.gson = gson;
    }

    @Override
    public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations, Retrofit retrofit) {
        return new WssResponseBodyConverter<>(type, gson);
    }

    @Override
    public Converter<?, RequestBody> requestBodyConverter(Type type, Annotation[] parameterAnnotations, Annotation[] methodAnnotations, Retrofit retrofit) {
        return new WssRequestBodyConverter<>(gson);
    }

    @Override
    public Converter<?, String> stringConverter(Type type, Annotation[] annotations, Retrofit retrofit) {
        return null;
    }

    public static class WssResponseBodyConverter<T> implements Converter<ResponseBody, T> {
        private final Gson gson;
        private final Type dataType;

        WssResponseBodyConverter(Type type, Gson gson) {
            this.gson = gson;
            this.dataType  = type;
        }

        @Override
        public T convert(ResponseBody value) throws IOException {
            BaseResponse<T> response = gson.fromJson(value.string(),
                    TypeToken.getParameterized(BaseResponse.class, dataType).getType());
            if (response.isSuccess()) {
                return response.model;
            } else {
                throw new WssNetException(response.responseCode, response.responseMsg);
            }
        }
    }

    public static class WssRequestBodyConverter<T> implements Converter<T, RequestBody> {
        private static final MediaType MEDIA_TYPE = MediaType.parse("application/json; charset=UTF-8");
        private static final Charset UTF_8 = Charset.forName("UTF-8");

        private Gson gson;

        public WssRequestBodyConverter(Gson gson) {
            this.gson = gson;
        }

        @Override
        public RequestBody convert(T value) throws IOException {
            BaseRequest request = new BaseRequest();

            try {
                request.reqData = WssNetHelper.getInstance().encryto(gson.toJson(value));
            } catch (Exception e) {
                e.printStackTrace();
            }

            TypeAdapter<BaseRequest> adapter = gson.getAdapter(BaseRequest.class);
            Buffer buffer = new Buffer();
            Writer writer = new OutputStreamWriter(buffer.outputStream(), UTF_8);
            JsonWriter jsonWriter = gson.newJsonWriter(writer);
            adapter.write(jsonWriter, request);
            jsonWriter.close();
            return RequestBody.create(MEDIA_TYPE, buffer.readByteString());
        }
    }
}

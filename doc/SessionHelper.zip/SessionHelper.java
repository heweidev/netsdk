package com.baoneng.wss.network;


import android.content.Context;

import com.baoneng.bnfinance.security.AES;
import com.baoneng.wss.authentication.login.LoginHelper;
import com.baoneng.wss.network.model.common.UpdateSessionResp;
import com.baoneng.wss.network.model.user.LoginReq;
import com.baoneng.wss.network.model.user.UserInfo;
import com.baoneng.wss.network.rx.ErrorConsumer;
import com.baoneng.wss.utils.AndroidUtils;
import com.baoneng.wss.utils.SecurityUtils;
import com.hewei.netsdk.CryptoEngine;
import com.hewei.netsdk.NetManager;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by fengyinpeng on 2018/2/11.
 */

public class SessionHelper {
    public interface SessionApi {
        @POST("wss-intf-portal.updateSession")
        Observable<UpdateSessionResp> updateSession(@Body String key);

        @POST(BNUrl.HEADER_PORTAL + "login")
        Observable<UserInfo> login(@Body LoginReq req);
    }

    private static String sEncryptoKey;

    public static CryptoEngine getCryptoEngine() {
        return new CryptoEngine() {
            @Override
            public String encrypt(String raw) {
                try {
                    return AES.encrypt(raw, sEncryptoKey);
                } catch (Exception e) {
                    return raw;
                }
            }

            @Override
            public String md5(String raw) {
                return AndroidUtils.MD5(raw.getBytes());
            }

            @Override
            public String decrypt(String raw) throws Exception {
                return AES.decrypt(raw, sEncryptoKey);
            }
        };
    }

    public static void login(final Context context, final String userName, final String password) {
        String[] aesKeys = getAesKeys(context);
        final SessionApi api = NetManager.getInstance().createApi(SessionApi.class);
        sEncryptoKey = aesKeys[0];

        api.updateSession(aesKeys[0])
                .flatMap(new Function<UpdateSessionResp, ObservableSource<UserInfo>>() {
                    @Override
                    public ObservableSource<UserInfo> apply(UpdateSessionResp resp) throws Exception {
                        String[] newKeys = getAesKeys(context);
                        LoginReq req = new LoginReq();
                        req.loginName = userName;
                        req.loginPwd = LoginHelper.getEncryptedText(context, password);
                        req.encKey = newKeys[0];
                        sEncryptoKey = newKeys[0];

                        return api.login(req).subscribeOn(Schedulers.io());
                    }
                }).subscribe(new Consumer<UserInfo>() {   // onNext
                    @Override
                    public void accept(UserInfo userInfo) throws Exception {
                        UserInfo.setIns(userInfo);
                    }
                }, ErrorConsumer.INSTANCE);
    }

    private static String[] getAesKeys(Context context) {
        String tempAesKey = Network.ins().getTempAesKey();
        if (tempAesKey == null) {
            String[] aesKeys = SecurityUtils.generateRandomAesKeyByRsa(context);
            Network.ins().setTempAesKey(aesKeys[0]);
            return aesKeys;
        }
        String aesKeyWithRsa = SecurityUtils.encryptByRSA(tempAesKey, context);
        return new String[]{tempAesKey, aesKeyWithRsa};
    }
}
